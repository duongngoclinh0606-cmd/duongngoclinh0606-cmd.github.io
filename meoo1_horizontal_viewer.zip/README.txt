Bản Bio Meoo1: mạng xã hội hàng ngang, trạng thái hoạt động, nhạc nền và bộ đếm lượt xem trên từng thiết bị.
Lưu ý: bộ đếm hiện tại là lượt xem trên thiết bị/trình duyệt, không phải tổng người xem toàn cầu. Muốn số liệu toàn cầu cần tích hợp dịch vụ counter bên ngoài.
